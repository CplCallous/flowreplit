import React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import { requireNativeViewManager } from 'expo-modules-core';

let NativeWidgetView: React.ComponentType<{ widgetId: number; style?: StyleProp<ViewStyle> }> | null = null;
try {
  NativeWidgetView = requireNativeViewManager('SwiftLauncher');
} catch {
  NativeWidgetView = null;
}

export function WidgetView({ widgetId, style }: { widgetId: number; style?: StyleProp<ViewStyle> }) {
  if (!NativeWidgetView) return null;
  return <NativeWidgetView widgetId={widgetId} style={style} />;
}
