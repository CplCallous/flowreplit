package expo.modules.swiftlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Base64
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayOutputStream

object IconPackHelper {
  private val cache = HashMap<String, Map<String, String>>()

  private fun load(context: Context, pack: String): Map<String, String> {
    val cached = cache[pack]
    if (cached != null) return cached
    val mapping = HashMap<String, String>()
    try {
      val resources = context.packageManager.getResourcesForApplication(pack)
      var parser: XmlPullParser? = null
      val xmlId = resources.getIdentifier("appfilter", "xml", pack)
      if (xmlId != 0) {
        parser = resources.getXml(xmlId)
      } else {
        try {
          val packContext = context.createPackageContext(pack, 0)
          val created = XmlPullParserFactory.newInstance().newPullParser()
          created.setInput(packContext.assets.open("appfilter.xml"), "utf-8")
          parser = created
        } catch (_: Exception) {
          parser = null
        }
      }
      if (parser != null) {
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
          if (event == XmlPullParser.START_TAG && parser.name == "item") {
            val component = parser.getAttributeValue(null, "component")
            val drawable = parser.getAttributeValue(null, "drawable")
            if (component != null && drawable != null && component.startsWith("ComponentInfo{")) {
              val packageName = component.removePrefix("ComponentInfo{").removeSuffix("}").substringBefore('/')
              if (!mapping.containsKey(packageName)) mapping[packageName] = drawable
            }
          }
          event = parser.next()
        }
      }
    } catch (_: Exception) {
      // A broken icon pack simply provides no icons.
    }
    cache[pack] = mapping
    return mapping
  }

  fun iconFor(context: Context, pack: String, packageName: String): String? {
    try {
      val drawableName = load(context, pack)[packageName] ?: return null
      val resources = context.packageManager.getResourcesForApplication(pack)
      val id = resources.getIdentifier(drawableName, "drawable", pack)
      if (id == 0) return null
      val drawable = resources.getDrawable(id, null) ?: return null
      return toDataUri(drawable)
    } catch (_: Exception) {
      return null
    }
  }

  private fun toDataUri(drawable: Drawable): String {
    val width = drawable.intrinsicWidth.coerceAtLeast(1).coerceAtMost(256)
    val height = drawable.intrinsicHeight.coerceAtLeast(1).coerceAtMost(256)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, width, height)
    drawable.draw(canvas)
    val stream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream)
    return "data:image/png;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
  }
}
