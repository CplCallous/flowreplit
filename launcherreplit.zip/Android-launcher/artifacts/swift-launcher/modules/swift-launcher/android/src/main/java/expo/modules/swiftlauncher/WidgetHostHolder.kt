package expo.modules.swiftlauncher

import android.appwidget.AppWidgetHost
import android.content.Context

object WidgetHostHolder {
  private const val HOST_ID = 4242
  private var host: AppWidgetHost? = null

  @Synchronized
  fun get(context: Context): AppWidgetHost {
    val existing = host
    if (existing != null) return existing
    val created = AppWidgetHost(context.applicationContext, HOST_ID)
    created.startListening()
    host = created
    return created
  }
}
