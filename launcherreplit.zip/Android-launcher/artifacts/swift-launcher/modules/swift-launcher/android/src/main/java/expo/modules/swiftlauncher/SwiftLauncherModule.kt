package expo.modules.swiftlauncher

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.UserManager
import android.provider.CalendarContract
import android.provider.Settings
import android.util.Base64
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.ByteArrayOutputStream

class SwiftLauncherModule : Module() {
  private fun activeController(context: Context): MediaController? {
    val manager = context.getSystemService(MediaSessionManager::class.java) ?: return null
    val controllers = manager.getActiveSessions(ComponentName(context, LauncherNotificationListener::class.java))
    return controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
      ?: controllers.firstOrNull()
  }

  override fun definition() = ModuleDefinition {
    Name("SwiftLauncher")

    OnCreate {
      val context = appContext.reactContext
      if (context != null) BluetoothTracker.start(context)
    }

    AsyncFunction("getInstalledApps") {
      val context = appContext.reactContext ?: return@AsyncFunction emptyList<Map<String, String>>()
      val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      val activities = if (Build.VERSION.SDK_INT >= 33) {
        context.packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
      } else {
        @Suppress("DEPRECATION")
        context.packageManager.queryIntentActivities(intent, 0)
      }
      activities
        .filter { it.activityInfo?.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
          mapOf(
            "packageName" to it.activityInfo.packageName,
            "name" to it.loadLabel(context.packageManager).toString()
          )
        }
        .sortedBy { it["name"]?.lowercase() ?: "" }
    }

    AsyncFunction("launchApp") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        ?: return@AsyncFunction false
      launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(launchIntent)
      true
    }

    AsyncFunction("openAppInfo") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction
      val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    AsyncFunction("uninstallApp") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction
      val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    AsyncFunction("openHomeSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      val intent = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    AsyncFunction("openNotificationAccessSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      context.startActivity(
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }

    Function("hasNotificationAccess") {
      val context = appContext.reactContext ?: return@Function false
      val enabled = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
      ) ?: return@Function false
      enabled.contains(context.packageName)
    }

    Function("getNotificationPreviews") {
      LauncherNotificationListener.previews.toMap()
    }

    AsyncFunction("setNotificationPreviewCollection") { enabled: Boolean ->
      val context = appContext.reactContext ?: return@AsyncFunction
      context.getSharedPreferences("swift_launcher", android.content.Context.MODE_PRIVATE)
        .edit()
        .putBoolean("notification_previews_enabled", enabled)
        .apply()
      if (!enabled) LauncherNotificationListener.previews.clear()
    }

    AsyncFunction("openUsageAccessSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      context.startActivity(
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }

    Function("hasUsageAccess") {
      val context = appContext.reactContext ?: return@Function false
      val appOps = context.getSystemService(AppOpsManager::class.java)
      val mode = if (Build.VERSION.SDK_INT >= 29) {
        appOps.unsafeCheckOpNoThrow(
          AppOpsManager.OPSTR_GET_USAGE_STATS,
          android.os.Process.myUid(),
          context.packageName
        )
      } else {
        @Suppress("DEPRECATION")
        appOps.checkOpNoThrow(
          AppOpsManager.OPSTR_GET_USAGE_STATS,
          android.os.Process.myUid(),
          context.packageName
        )
      }
      mode == AppOpsManager.MODE_ALLOWED
    }

    AsyncFunction("getMostUsedApps") {
      val context = appContext.reactContext ?: return@AsyncFunction emptyList<String>()
      val manager = context.getSystemService(UsageStatsManager::class.java)
      val now = System.currentTimeMillis()
      manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7L * 24 * 60 * 60 * 1000, now)
        .orEmpty()
        .filter { it.totalTimeInForeground > 0 && it.packageName != context.packageName }
        .sortedByDescending { it.totalTimeInForeground }
        .map { it.packageName }
        .distinct()
        .take(12)
    }

    AsyncFunction("openAccessibilitySettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      context.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }

    AsyncFunction("expandNotificationShade") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      try {
        val statusBar = context.getSystemService("statusbar") ?: return@AsyncFunction false
        statusBar.javaClass.getMethod("expandNotificationsPanel").invoke(statusBar)
        true
      } catch (_: Exception) {
        false
      }
    }

    Function("hasLockService") {
      val context = appContext.reactContext ?: return@Function false
      val enabled = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
      ) ?: return@Function false
      val component = ComponentName(context, LauncherAccessibilityService::class.java).flattenToString()
      enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    AsyncFunction("lockScreen") {
      LauncherAccessibilityService.lockNow()
    }

    AsyncFunction("getAppIcon") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction null
      val drawable = try {
        context.packageManager.getApplicationIcon(packageName)
      } catch (_: PackageManager.NameNotFoundException) {
        return@AsyncFunction null
      }
      val width = drawable.intrinsicWidth.coerceAtLeast(1).coerceAtMost(256)
      val height = drawable.intrinsicHeight.coerceAtLeast(1).coerceAtMost(256)
      val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)
      drawable.setBounds(0, 0, width, height)
      drawable.draw(canvas)
      val stream = ByteArrayOutputStream()
      bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream)
      "data:image/png;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    Function("hasCalendarPermission") {
      val context = appContext.reactContext ?: return@Function false
      context.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    }

    AsyncFunction("getCalendarEvents") { startMs: Double, endMs: Double ->
      val context = appContext.reactContext
      val results = mutableListOf<Map<String, Any?>>()
      if (context != null &&
        context.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
      ) {
        val projection = arrayOf(
          CalendarContract.Instances.TITLE,
          CalendarContract.Instances.BEGIN,
          CalendarContract.Instances.END,
          CalendarContract.Instances.ALL_DAY,
          CalendarContract.Instances.EVENT_LOCATION
        )
        val cursor = CalendarContract.Instances.query(
          context.contentResolver,
          projection,
          startMs.toLong(),
          endMs.toLong()
        )
        if (cursor != null) {
          try {
            while (cursor.moveToNext() && results.size < 25) {
              results.add(
                mapOf(
                  "title" to (cursor.getString(0) ?: ""),
                  "begin" to cursor.getLong(1).toDouble(),
                  "end" to cursor.getLong(2).toDouble(),
                  "allDay" to (cursor.getInt(3) == 1),
                  "location" to (cursor.getString(4) ?: "")
                )
              )
            }
          } finally {
            cursor.close()
          }
        }
      }
      results.sortedBy { (it["begin"] as? Double) ?: 0.0 }
    }

    AsyncFunction("getUsageToday") {
      val context = appContext.reactContext
      val manager = context?.getSystemService(UsageStatsManager::class.java)
      val usage = mutableMapOf<String, Double>()
      if (context != null && manager != null) {
        val calendar = java.util.Calendar.getInstance()
        calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
        calendar.set(java.util.Calendar.MINUTE, 0)
        calendar.set(java.util.Calendar.SECOND, 0)
        calendar.set(java.util.Calendar.MILLISECOND, 0)
        val aggregated = manager.queryAndAggregateUsageStats(calendar.timeInMillis, System.currentTimeMillis())
        for ((packageName, stats) in aggregated) {
          if (stats.totalTimeInForeground > 0 && packageName != context.packageName) {
            usage[packageName] = stats.totalTimeInForeground.toDouble()
          }
        }
      }
      usage
    }

    AsyncFunction("getProfileApps") {
      val context = appContext.reactContext
      val result = mutableListOf<Map<String, Any?>>()
      try {
        if (context != null) {
          val launcherApps = context.getSystemService(LauncherApps::class.java)
          val userManager = context.getSystemService(UserManager::class.java)
          val myUser = android.os.Process.myUserHandle()
          if (launcherApps != null && userManager != null) {
            for (profile in launcherApps.profiles) {
              if (profile == myUser) continue
              val serial = userManager.getSerialNumberForUser(profile)
              for (info in launcherApps.getActivityList(null, profile)) {
                result.add(
                  mapOf(
                    "packageName" to info.applicationInfo.packageName,
                    "name" to info.label.toString(),
                    "profile" to serial.toDouble()
                  )
                )
              }
            }
          }
        }
      } catch (_: Exception) {
        // Android only lists other profiles to the default home app.
      }
      result
    }

    AsyncFunction("launchProfileApp") { packageName: String, serial: Double ->
      val context = appContext.reactContext
      var launched = false
      try {
        if (context != null) {
          val launcherApps = context.getSystemService(LauncherApps::class.java)
          val userManager = context.getSystemService(UserManager::class.java)
          val user = userManager?.getUserForSerialNumber(serial.toLong())
          if (launcherApps != null && user != null) {
            val activity = launcherApps.getActivityList(packageName, user).firstOrNull()
            if (activity != null) {
              launcherApps.startMainActivity(activity.componentName, user, null, null)
              launched = true
            }
          }
        }
      } catch (_: Exception) {
        launched = false
      }
      launched
    }

    Function("getConnectedBluetoothDevices") {
      val context = appContext.reactContext
      val devices = LinkedHashMap<String, String>()
      devices.putAll(BluetoothTracker.connected)
      try {
        val audio = context?.getSystemService(AudioManager::class.java)
        if (audio != null) {
          for (device in audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            if (device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
              val address = if (Build.VERSION.SDK_INT >= 28) device.address else ""
              if (!address.isNullOrEmpty()) devices[address] = device.productName.toString()
            }
          }
        }
      } catch (_: Exception) {
        // Audio device lookup is best effort.
      }
      devices.map { mapOf("address" to it.key, "name" to it.value) }
    }

    Function("hasHeadphones") {
      val context = appContext.reactContext
      var found = false
      try {
        val audio = context?.getSystemService(AudioManager::class.java)
        if (audio != null) {
          val types = setOf(3, 4, 8, 22, 26)
          for (device in audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            if (types.contains(device.type)) found = true
          }
        }
      } catch (_: Exception) {
        found = false
      }
      found
    }

    AsyncFunction("getBondedBluetoothDevices") {
      val context = appContext.reactContext
      val result = mutableListOf<Map<String, String>>()
      try {
        val adapter = context?.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter != null) {
          for (device in adapter.bondedDevices) {
            val address: String = device.address
            result.add(mapOf("address" to address, "name" to (device.name ?: address)))
          }
        }
      } catch (_: SecurityException) {
        // Bluetooth permission has not been granted yet.
      }
      result
    }

    AsyncFunction("getIconPacks") {
      val context = appContext.reactContext
      val packs = LinkedHashMap<String, String>()
      if (context != null) {
        val pm = context.packageManager
        val actions = listOf(
          "org.adw.launcher.THEMES",
          "com.novalauncher.THEME",
          "com.gau.go.launcherex.theme"
        )
        for (action in actions) {
          val resolved = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(Intent(action), PackageManager.ResolveInfoFlags.of(0))
          } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(Intent(action), 0)
          }
          for (info in resolved) {
            packs[info.activityInfo.packageName] = info.loadLabel(pm).toString()
          }
        }
      }
      packs.map { mapOf("packageName" to it.key, "name" to it.value) }
    }

    AsyncFunction("getIconPackIcon") { packName: String, packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction null
      IconPackHelper.iconFor(context, packName, packageName)
    }

    Function("getMediaSession") {
      val context = appContext.reactContext
      var result: Map<String, Any?>? = null
      try {
        if (context != null) {
          val controller = activeController(context)
          if (controller != null) {
            val metadata = controller.metadata
            result = mapOf(
              "packageName" to controller.packageName,
              "title" to (metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""),
              "artist" to (metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""),
              "playing" to (controller.playbackState?.state == PlaybackState.STATE_PLAYING)
            )
          }
        }
      } catch (_: SecurityException) {
        result = null
      }
      result
    }

    AsyncFunction("mediaControl") { action: String ->
      val context = appContext.reactContext
      var done = false
      try {
        if (context != null) {
          val controls = activeController(context)?.transportControls
          if (controls != null) {
            when (action) {
              "play" -> controls.play()
              "pause" -> controls.pause()
              "next" -> controls.skipToNext()
              "previous" -> controls.skipToPrevious()
            }
            done = true
          }
        }
      } catch (_: SecurityException) {
        done = false
      }
      done
    }

    AsyncFunction("setQuickRepliesCollection") { enabled: Boolean ->
      val context = appContext.reactContext
      if (context != null) {
        context.getSharedPreferences("swift_launcher", Context.MODE_PRIVATE)
          .edit()
          .putBoolean("quick_replies_enabled", enabled)
          .apply()
      }
      if (!enabled) LauncherNotificationListener.replyTargets.clear()
      enabled
    }

    Function("getReplyTargets") {
      LauncherNotificationListener.replyTargets.values
        .sortedByDescending { it.postedAt }
        .take(5)
        .map { mapOf("packageName" to it.packageName, "title" to it.title, "text" to it.text) }
    }

    AsyncFunction("sendQuickReply") { packageName: String, message: String ->
      val context = appContext.reactContext
      val target = LauncherNotificationListener.replyTargets[packageName]
      var sent = false
      if (context != null && target != null) {
        try {
          val inputs = target.action.remoteInputs
          if (inputs != null && inputs.isNotEmpty()) {
            val intent = Intent()
            val bundle = android.os.Bundle()
            for (input in inputs) bundle.putCharSequence(input.resultKey, message)
            android.app.RemoteInput.addResultsToIntent(inputs, intent, bundle)
            target.action.actionIntent.send(context, 0, intent)
            sent = true
          }
        } catch (_: Exception) {
          sent = false
        }
      }
      sent
    }

    AsyncFunction("getAppShortcuts") { packageName: String ->
      val context = appContext.reactContext
      val result = mutableListOf<Map<String, String>>()
      try {
        if (context != null && Build.VERSION.SDK_INT >= 25) {
          val launcherApps = context.getSystemService(LauncherApps::class.java)
          val query = LauncherApps.ShortcutQuery()
          query.setPackage(packageName)
          query.setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
              LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
              LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
          )
          val shortcuts = launcherApps?.getShortcuts(query, android.os.Process.myUserHandle())
          if (shortcuts != null) {
            for (shortcut in shortcuts) {
              if (shortcut.isEnabled) {
                result.add(mapOf("id" to shortcut.id, "label" to (shortcut.shortLabel?.toString() ?: shortcut.id)))
              }
            }
          }
        }
      } catch (_: Exception) {
        // Android only shares shortcuts with the default home app.
      }
      result.take(6)
    }

    AsyncFunction("startAppShortcut") { packageName: String, shortcutId: String ->
      val context = appContext.reactContext
      var started = false
      try {
        if (context != null && Build.VERSION.SDK_INT >= 25) {
          val launcherApps = context.getSystemService(LauncherApps::class.java)
          launcherApps?.startShortcut(packageName, shortcutId, null, null, android.os.Process.myUserHandle())
          started = launcherApps != null
        }
      } catch (_: Exception) {
        started = false
      }
      started
    }
  }
}
