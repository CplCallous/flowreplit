package expo.modules.swiftlauncher

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Base64
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.ByteArrayOutputStream

class SwiftLauncherModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("SwiftLauncher")

    AsyncFunction("getInstalledApps") {
      val context = appContext.reactContext ?: return@AsyncFunction emptyList<Map<String, String>>()
      val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      val activities = if (Build.VERSION.SDK_INT >= 33) {
        context.packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
      } else {
        @Suppress("DEPRECATION")
        context.packageManager.queryIntentActivities(intent, 0)
      }
      activities
        .filter { it.activityInfo?.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
          mapOf(
            "packageName" to it.activityInfo.packageName,
            "name" to it.loadLabel(context.packageManager).toString()
          )
        }
        .sortedBy { it["name"]?.lowercase() ?: "" }
    }

    AsyncFunction("launchApp") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction false
      val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        ?: return@AsyncFunction false
      launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(launchIntent)
      true
    }

    AsyncFunction("openAppInfo") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction
      val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    AsyncFunction("uninstallApp") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction
      val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    AsyncFunction("openHomeSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      val intent = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    AsyncFunction("openNotificationAccessSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      context.startActivity(
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }

    Function("hasNotificationAccess") {
      val context = appContext.reactContext ?: return@Function false
      val enabled = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
      ) ?: return@Function false
      enabled.contains(context.packageName)
    }

    Function("getNotificationPreviews") {
      LauncherNotificationListener.previews.toMap()
    }

    AsyncFunction("setNotificationPreviewCollection") { enabled: Boolean ->
      val context = appContext.reactContext ?: return@AsyncFunction
      context.getSharedPreferences("swift_launcher", android.content.Context.MODE_PRIVATE)
        .edit()
        .putBoolean("notification_previews_enabled", enabled)
        .apply()
      if (!enabled) LauncherNotificationListener.previews.clear()
    }

    AsyncFunction("openUsageAccessSettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      context.startActivity(
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }

    Function("hasUsageAccess") {
      val context = appContext.reactContext ?: return@Function false
      val appOps = context.getSystemService(AppOpsManager::class.java)
      val mode = if (Build.VERSION.SDK_INT >= 29) {
        appOps.unsafeCheckOpNoThrow(
          AppOpsManager.OPSTR_GET_USAGE_STATS,
          android.os.Process.myUid(),
          context.packageName
        )
      } else {
        @Suppress("DEPRECATION")
        appOps.checkOpNoThrow(
          AppOpsManager.OPSTR_GET_USAGE_STATS,
          android.os.Process.myUid(),
          context.packageName
        )
      }
      mode == AppOpsManager.MODE_ALLOWED
    }

    AsyncFunction("getMostUsedApps") {
      val context = appContext.reactContext ?: return@AsyncFunction emptyList<String>()
      val manager = context.getSystemService(UsageStatsManager::class.java)
      val now = System.currentTimeMillis()
      manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7L * 24 * 60 * 60 * 1000, now)
        .orEmpty()
        .filter { it.totalTimeInForeground > 0 && it.packageName != context.packageName }
        .sortedByDescending { it.totalTimeInForeground }
        .map { it.packageName }
        .distinct()
        .take(12)
    }

    AsyncFunction("openAccessibilitySettings") {
      val context = appContext.reactContext ?: return@AsyncFunction
      context.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }

    AsyncFunction("expandNotificationShade") {
      val context = appContext.reactContext ?: return@AsyncFunction false
      try {
        val statusBar = context.getSystemService("statusbar") ?: return@AsyncFunction false
        statusBar.javaClass.getMethod("expandNotificationsPanel").invoke(statusBar)
        true
      } catch (_: Exception) {
        false
      }
    }

    Function("hasLockService") {
      val context = appContext.reactContext ?: return@Function false
      val enabled = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
      ) ?: return@Function false
      val component = ComponentName(context, LauncherAccessibilityService::class.java).flattenToString()
      enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    AsyncFunction("lockScreen") {
      LauncherAccessibilityService.lockNow()
    }

    AsyncFunction("getAppIcon") { packageName: String ->
      val context = appContext.reactContext ?: return@AsyncFunction null
      val drawable = try {
        context.packageManager.getApplicationIcon(packageName)
      } catch (_: PackageManager.NameNotFoundException) {
        return@AsyncFunction null
      }
      val width = drawable.intrinsicWidth.coerceAtLeast(1).coerceAtMost(256)
      val height = drawable.intrinsicHeight.coerceAtLeast(1).coerceAtMost(256)
      val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)
      drawable.setBounds(0, 0, width, height)
      drawable.draw(canvas)
      val stream = ByteArrayOutputStream()
      bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream)
      "data:image/png;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
  }
}
