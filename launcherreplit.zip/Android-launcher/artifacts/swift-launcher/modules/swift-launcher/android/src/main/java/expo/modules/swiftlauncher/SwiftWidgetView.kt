package expo.modules.swiftlauncher

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.widget.LinearLayout
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

class SwiftWidgetView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  override val shouldUseAndroidLayout = true
  private var hostView: AppWidgetHostView? = null
  private var currentId = -1

  fun setWidget(id: Int) {
    if (id == currentId) return
    currentId = id
    removeAllViews()
    hostView = null
    if (id < 0) return
    try {
      val manager = AppWidgetManager.getInstance(context)
      val info = manager.getAppWidgetInfo(id) ?: return
      val view = WidgetHostHolder.get(context).createView(context, id, info)
      hostView = view
      addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
      pushSize()
    } catch (_: Exception) {
      hostView = null
    }
  }

  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
    super.onSizeChanged(w, h, oldw, oldh)
    pushSize()
  }

  private fun pushSize() {
    val density = resources.displayMetrics.density
    val widthDp = (width / density).toInt()
    val heightDp = (height / density).toInt()
    if (widthDp > 0 && heightDp > 0) {
      hostView?.updateAppWidgetSize(null, widthDp, heightDp, widthDp, heightDp)
    }
  }
}
