package expo.modules.swiftlauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import java.util.concurrent.ConcurrentHashMap

class LauncherNotificationListener : NotificationListenerService() {
  override fun onNotificationPosted(sbn: StatusBarNotification) {
    val enabled = getSharedPreferences("swift_launcher", MODE_PRIVATE)
      .getBoolean("notification_previews_enabled", false)
    if (!enabled) return
    val title = sbn.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
      ?.takeIf { it.isNotBlank() } ?: return
    previews[sbn.packageName] = title.take(120)
  }

  companion object {
    val previews = ConcurrentHashMap<String, String>()
  }
}
