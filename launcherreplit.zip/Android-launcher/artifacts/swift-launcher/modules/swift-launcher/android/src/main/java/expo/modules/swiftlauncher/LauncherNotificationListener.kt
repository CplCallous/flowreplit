package expo.modules.swiftlauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap

data class ReplyTarget(
  val packageName: String,
  val title: String,
  val text: String,
  val action: Notification.Action,
  val postedAt: Long
)

class LauncherNotificationListener : NotificationListenerService() {
  override fun onNotificationPosted(sbn: StatusBarNotification) {
    val prefs = getSharedPreferences("swift_launcher", MODE_PRIVATE)
    val previewsOn = prefs.getBoolean("notification_previews_enabled", false)
    val repliesOn = prefs.getBoolean("quick_replies_enabled", false)
    if (!previewsOn && !repliesOn) return
    val extras = sbn.notification.extras
    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
      ?.takeIf { it.isNotBlank() }
    if (previewsOn && title != null) {
      previews[sbn.packageName] = title.take(120)
    }
    if (repliesOn) {
      val actions = sbn.notification.actions
      if (actions != null) {
        for (action in actions) {
          val inputs = action.remoteInputs
          if (inputs != null && inputs.isNotEmpty()) {
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            replyTargets[sbn.packageName] = ReplyTarget(
              sbn.packageName,
              title ?: sbn.packageName,
              text.take(160),
              action,
              System.currentTimeMillis()
            )
            break
          }
        }
      }
    }
  }

  override fun onNotificationRemoved(sbn: StatusBarNotification) {
    try {
      val remaining = activeNotifications.filter { it.packageName == sbn.packageName }
      if (remaining.isEmpty()) {
        previews.remove(sbn.packageName)
        replyTargets.remove(sbn.packageName)
      }
    } catch (_: Exception) {
      // The listener may be disconnected; stale previews are cleared on the next refresh.
    }
  }

  companion object {
    val previews = ConcurrentHashMap<String, String>()
    val replyTargets = ConcurrentHashMap<String, ReplyTarget>()
  }
}
