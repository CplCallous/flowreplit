package expo.modules.swiftlauncher

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class LauncherAccessibilityService : AccessibilityService() {
  override fun onServiceConnected() {
    service = this
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

  override fun onInterrupt() = Unit

  override fun onDestroy() {
    if (service === this) service = null
    super.onDestroy()
  }

  companion object {
    @Volatile
    private var service: LauncherAccessibilityService? = null

    fun lockNow(): Boolean {
      val active = service ?: return false
      return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
        active.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    }
  }
}
