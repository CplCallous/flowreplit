import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo-modules-core';
import type { LauncherApp } from '@/data/launcher';

export type CalendarEvent = { title: string; begin: number; end: number; allDay: boolean; location: string };

type NativeLauncherModule = {
  getInstalledApps(): Promise<LauncherApp[]>;
  launchApp(packageName: string): Promise<boolean>;
  openAppInfo(packageName: string): Promise<void>;
  uninstallApp(packageName: string): Promise<void>;
  openHomeSettings(): Promise<void>;
  openNotificationAccessSettings(): Promise<void>;
  hasNotificationAccess(): boolean;
  getNotificationPreviews(): Record<string, string>;
  setNotificationPreviewCollection(enabled: boolean): Promise<void>;
  openUsageAccessSettings(): Promise<void>;
  hasUsageAccess(): boolean;
  getMostUsedApps(): Promise<string[]>;
  openAccessibilitySettings(): Promise<void>;
  getAppIcon(packageName: string): Promise<string | null>;
  expandNotificationShade(): Promise<boolean>;
  hasLockService(): boolean;
  lockScreen(): Promise<boolean>;
  hasCalendarPermission(): boolean;
  getCalendarEvents(startMs: number, endMs: number): Promise<CalendarEvent[]>;
  getUsageToday(): Promise<Record<string, number>>;
  getProfileApps(): Promise<Array<{ packageName: string; name: string; profile: number }>>;
  launchProfileApp(packageName: string, profile: number): Promise<boolean>;
  getConnectedBluetoothDevices(): Array<{ address: string; name: string }>;
  hasHeadphones(): boolean;
  getBondedBluetoothDevices(): Promise<Array<{ address: string; name: string }>>;
  getIconPacks(): Promise<Array<{ packageName: string; name: string }>>;
  getIconPackIcon(packName: string, packageName: string): Promise<string | null>;
  getMediaSession(): { packageName: string; title: string; artist: string; playing: boolean } | null;
  mediaControl(action: 'play' | 'pause' | 'next' | 'previous'): Promise<boolean>;
  setQuickRepliesCollection(enabled: boolean): Promise<boolean>;
  getReplyTargets(): Array<{ packageName: string; title: string; text: string }>;
  sendQuickReply(packageName: string, message: string): Promise<boolean>;
  getAppShortcuts(packageName: string): Promise<Array<{ id: string; label: string }>>;
  startAppShortcut(packageName: string, shortcutId: string): Promise<boolean>;
};

export const nativeLauncher =
  Platform.OS === 'android'
    ? requireOptionalNativeModule<NativeLauncherModule>('SwiftLauncher')
    : null;

export const isNativeLauncherAvailable = Boolean(nativeLauncher);
